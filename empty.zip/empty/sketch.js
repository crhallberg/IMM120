// Variables

// Load images and sounds
function preload() {
}

// Run once at the start
function setup() {
  var canvas = createCanvas(200, 200);
  canvas.parent('sketch');
}

// Run forever after setup
function draw() {
}