// Variables
var socket = window.io.connect('http://207.172.118.50:8120');
var room = 'main';

// Run once at the start
function setup() {
  var canvas = createCanvas(800, 600).parent('sketch');
  socket.emit('join', room);
}

// Run forever after setup
function draw() {
  
}